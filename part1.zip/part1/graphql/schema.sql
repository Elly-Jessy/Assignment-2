CREATE TYPE UserRole AS ENUM ('HoD', 'Supervisor', 'Employee');

CREATE TABLE departments (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    hod_id INTEGER REFERENCES users(id)
);

CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    first_name VARCHAR(255) NOT NULL,
    last_name VARCHAR(255) NOT NULL,
    job_title VARCHAR(255),
    position VARCHAR(255),
    role UserRole NOT NULL,
    department_id INTEGER REFERENCES departments(id)
);

CREATE TABLE department_objectives (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    weight FLOAT NOT NULL,
    department_id INTEGER NOT NULL REFERENCES departments(id)
);

CREATE TABLE kpis (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id),
    name VARCHAR(255) NOT NULL,
    metric VARCHAR(255),
    unit VARCHAR(255),
    score FLOAT
);

CREATE TABLE kpi_objective_relations (
    kpi_id INTEGER NOT NULL REFERENCES kpis(id),
    department_objective_id INTEGER NOT NULL REFERENCES department_objectives(id),
    PRIMARY KEY (kpi_id, department_objective_id)
);

CREATE TABLE supervisor_grades (
    supervisor_id INTEGER NOT NULL REFERENCES users(id),
    kpi_id INTEGER NOT NULL REFERENCES kpis(id),
    grade FLOAT NOT NULL,
    PRIMARY KEY (supervisor_id, kpi_id)
);

CREATE TABLE employee_supervisor_feedbacks (
    employee_id INTEGER NOT NULL REFERENCES users(id),
    supervisor_id INTEGER NOT NULL REFERENCES users(id),
    grade FLOAT NOT NULL,
    feedback TEXT,
    PRIMARY KEY (employee_id, supervisor_id)
);
